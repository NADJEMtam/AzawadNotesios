import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'app_colors.dart';

class AppTheme {
  static final String? _arabicFont = GoogleFonts.tajawal().fontFamily;

  static ThemeData get lightTheme => ThemeData(
    useMaterial3: true,
    fontFamily: _arabicFont,
    textTheme: TextTheme(
      bodyLarge: GoogleFonts.tajawal(textStyle: const TextStyle(fontFamilyFallback: ['Roboto'])),
      bodyMedium: GoogleFonts.tajawal(textStyle: const TextStyle(fontFamilyFallback: ['Roboto'])),
      titleLarge: GoogleFonts.amiri(textStyle: const TextStyle(fontFamilyFallback: ['Roboto'], fontWeight: FontWeight.bold)),
    ),
    colorScheme: ColorScheme.fromSeed(
      seedColor: AppColors.azawadRed,
      brightness: Brightness.light,
    ),
    scaffoldBackgroundColor: const Color(0xFFFDFBF7), // Luxury Cream Paper
    appBarTheme: const AppBarTheme(
      backgroundColor: Color(0xFFFDFBF7),
      foregroundColor: AppColors.deepCharcoal,
      elevation: 0,
      centerTitle: true,
    ),
    cardTheme: CardThemeData(
      color: Colors.white,
      elevation: 2,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
    ),
  );

  static ThemeData darkTheme = ThemeData(
    useMaterial3: true,
    fontFamily: _arabicFont,
    textTheme: TextTheme(
      bodyLarge: GoogleFonts.tajawal(textStyle: const TextStyle(fontFamilyFallback: ['Roboto'])),
      bodyMedium: GoogleFonts.tajawal(textStyle: const TextStyle(fontFamilyFallback: ['Roboto'])),
      titleLarge: GoogleFonts.amiri(textStyle: const TextStyle(fontFamilyFallback: ['Roboto'], fontWeight: FontWeight.bold)),
    ),
    colorScheme: ColorScheme.dark(
      primary: AppColors.azawadRedDark,
      secondary: AppColors.azawadBlueDark,
      tertiary: AppColors.azawadYellowDark,
      surface: const Color(0xFF1A1A1A),
      onPrimary: AppColors.azawadWhite,
      onSecondary: AppColors.azawadWhite,
      onSurface: AppColors.azawadWhite,
    ),
    scaffoldBackgroundColor: const Color(0xFF121212), // Midnight Paper
    appBarTheme: const AppBarTheme(
      backgroundColor: Color(0xFF121212),
      foregroundColor: AppColors.azawadWhite,
      elevation: 0,
      centerTitle: true,
    ),
    floatingActionButtonTheme: const FloatingActionButtonThemeData(
      backgroundColor: AppColors.azawadYellowDark,
      foregroundColor: AppColors.deepCharcoal,
    ),
    cardTheme: CardThemeData(
      color: AppColors.surfaceCharcoal,
      elevation: 2,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
      ),
    ),
  );
}

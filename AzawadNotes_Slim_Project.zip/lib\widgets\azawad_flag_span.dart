import 'package:flutter/material.dart';

/// Renders the Azawad flag image inline with text, styled like a professional system emoji.
class AzawadFlagSpan extends WidgetSpan {
  AzawadFlagSpan({double fontSize = 22})
      : super(
          alignment: PlaceholderAlignment.middle,
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 2.5),
            child: Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(fontSize * 0.15),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withValues(alpha: 0.2),
                    blurRadius: 1.5,
                    offset: const Offset(0, 0.8),
                  ),
                ],
              ),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(fontSize * 0.15),
                child: Image.asset(
                  'assets/flags/azawad_flag.png',
                  height: fontSize * 0.95,
                  width: fontSize * 0.95 * 1.5, // Standard emoji flag ratio
                  fit: BoxFit.cover,
                  filterQuality: FilterQuality.high,
                  errorBuilder: (context, error, stackTrace) => 
                      Icon(Icons.flag, size: fontSize, color: Colors.red),
                ),
              ),
            ),
          ),
        );
}

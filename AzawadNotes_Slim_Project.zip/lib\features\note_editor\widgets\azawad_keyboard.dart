import 'package:flutter/material.dart';
import '../../../core/theme/app_colors.dart';

class AzawadKeyboard extends StatelessWidget {
  final Function(String) onKeyTap;
  final VoidCallback onBackspace;
  final VoidCallback onEnter;
  final VoidCallback onFlagTap;
  final VoidCallback onLanguageToggle;
  final bool isArabic;

  const AzawadKeyboard({
    super.key,
    required this.onKeyTap,
    required this.onBackspace,
    required this.onEnter,
    required this.onFlagTap,
    required this.onLanguageToggle,
    this.isArabic = true,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.black, // Dark background as requested
      padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 4),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          _buildRow(isArabic ? ["ض", "ص", "ث", "ق", "ف", "غ", "ع", "ه", "خ", "ح", "ج", "د"] : ["Q", "W", "E", "R", "T", "Y", "U", "I", "O", "P"]),
          _buildRow(isArabic ? ["ش", "س", "ي", "ب", "ل", "ا", "ت", "ن", "م", "ك", "ط"] : ["A", "S", "D", "F", "G", "H", "J", "K", "L"]),
          _buildThirdRow(),
          _buildBottomRow(),
        ],
      ),
    );
  }

  Widget _buildRow(List<String> keys) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: keys.map((key) => _KeyboardKey(label: key, onTap: () => onKeyTap(key))).toList(),
    );
  }

  Widget _buildThirdRow() {
    final keys = isArabic ? ["ئ", "ء", "ؤ", "ر", "لا", "ى", "ة", "و", "ز", "ظ"] : ["Z", "X", "C", "V", "B", "N", "M"];
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        if (!isArabic) _KeyboardKey(icon: Icons.keyboard_capslock, onTap: () {}), // Dummy shift
        ...keys.map((key) => _KeyboardKey(label: key, onTap: () => onKeyTap(key))),
        _KeyboardKey(icon: Icons.backspace, onTap: onBackspace),
      ],
    );
  }

  Widget _buildBottomRow() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        _KeyboardKey(label: isArabic ? "EN" : "AR", onTap: onLanguageToggle, color: AppColors.azawadBlue),
        _KeyboardKey(
          onTap: onFlagTap,
          color: Colors.transparent,
          child: Container(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(4),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withValues(alpha: 0.3),
                  blurRadius: 2,
                  offset: const Offset(0, 1),
                ),
              ],
            ),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(4),
              child: Image.asset(
                'assets/flags/azawad_flag.png',
                width: 40,
                height: 25,
                fit: BoxFit.cover,
                errorBuilder: (context, error, stackTrace) => const Icon(Icons.flag, color: Colors.white),
              ),
            ),
          ),
        ),
        _KeyboardKey(label: " ", width: 150, onTap: () => onKeyTap(" ")),
        _KeyboardKey(icon: Icons.keyboard_return, onTap: onEnter, color: AppColors.azawadRed),
      ],
    );
  }
}

class _KeyboardKey extends StatelessWidget {
  final String? label;
  final IconData? icon;
  final Widget? child;
  final VoidCallback onTap;
  final double width;
  final Color? color;

  const _KeyboardKey({
    this.label,
    this.icon,
    this.child,
    required this.onTap,
    this.width = 35,
    this.color,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(2.0),
      child: Material(
        color: color ?? Colors.grey[800],
        borderRadius: BorderRadius.circular(6),
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(6),
          child: Container(
            width: width,
            height: 45,
            alignment: Alignment.center,
            child: child ?? (icon != null 
              ? Icon(icon, color: Colors.white, size: 20)
              : Text(label!, style: const TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold))),
          ),
        ),
      ),
    );
  }
}

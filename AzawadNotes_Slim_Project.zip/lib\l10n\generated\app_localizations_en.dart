// ignore: unused_import
import 'package:intl/intl.dart' as intl;
import 'app_localizations.dart';

// ignore_for_file: type=lint

/// The translations for English (`en`).
class AppLocalizationsEn extends AppLocalizations {
  AppLocalizationsEn([String locale = 'en']) : super(locale);

  @override
  String get appTitle => 'Azawad Notes';

  @override
  String get searchNotes => 'Search notes...';

  @override
  String get noNotes => 'No notes found';

  @override
  String get addNote => 'Add Note';

  @override
  String get settings => 'Settings';

  @override
  String get darkMode => 'Dark Mode';

  @override
  String get language => 'Language';

  @override
  String get pinned => 'Pinned';

  @override
  String get delete => 'Delete';

  @override
  String get archive => 'Archive';

  @override
  String get title => 'Title';

  @override
  String get noteContent => 'Write your note here...';

  @override
  String get save => 'Save';

  @override
  String get trash => 'Trash';

  @override
  String get restore => 'Restore';

  @override
  String get emptyTrash => 'Empty Trash';

  @override
  String get permanentlyDelete => 'Permanently Delete';

  @override
  String get confirmEmptyTrash => 'Are you sure you want to empty the trash?';

  @override
  String get noTrash => 'Trash is empty';

  @override
  String get cancel => 'Cancel';

  @override
  String get about => 'About';

  @override
  String get version => 'Version';

  @override
  String get injectDemoData => 'Inject Demo Data';

  @override
  String get demoDataInjected => 'Demo data injected successfully';

  @override
  String get theme => 'Theme';

  @override
  String get light => 'Light';

  @override
  String get dark => 'Dark';

  @override
  String get privacyPolicy => 'Privacy Policy';
}

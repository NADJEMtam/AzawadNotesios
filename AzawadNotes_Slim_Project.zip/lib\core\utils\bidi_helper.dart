import 'package:flutter/material.dart';
import 'package:intl/intl.dart' as intl;

class BidiHelper {
  static TextDirection detectDirection(String text) {
    if (text.isEmpty) return TextDirection.ltr;
    
    // Check first strong character
    for (int i = 0; i < text.length; i++) {
      final char = text[i];
      if (intl.Bidi.isRtlLanguage(char)) {
        return TextDirection.rtl;
      }
      // Simple heuristic for Latin
      if (RegExp(r'[a-zA-Z]').hasMatch(char)) {
        return TextDirection.ltr;
      }
    }
    
    return TextDirection.ltr;
  }

  static TextAlign getTextAlign(String text) {
    return detectDirection(text) == TextDirection.rtl ? TextAlign.right : TextAlign.left;
  }
}

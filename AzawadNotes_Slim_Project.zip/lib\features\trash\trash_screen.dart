import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:lucide_icons_flutter/lucide_icons.dart';
import '../../providers/notes_provider.dart';
import '../../l10n/generated/app_localizations.dart';
import 'package:google_fonts/google_fonts.dart';

class TrashScreen extends ConsumerWidget {
  const TrashScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final trashNotes = ref.watch(trashNotesProvider);
    final l10n = AppLocalizations.of(context)!;

    return Scaffold(
      appBar: AppBar(
        title: Text(
          l10n.trash,
          style: GoogleFonts.cairo(fontWeight: FontWeight.bold),
        ),
        actions: [
          if (trashNotes.isNotEmpty)
            IconButton(
              icon: const Icon(LucideIcons.trash2, color: Colors.redAccent),
              onPressed: () => _confirmEmptyTrash(context, ref, l10n),
            ),
        ],
      ),
      body: trashNotes.isEmpty
          ? Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(LucideIcons.trash, size: 80, color: Colors.grey.withValues(alpha: 0.5)),
                  const SizedBox(height: 16),
                  Text(
                    l10n.noTrash,
                    style: GoogleFonts.cairo(fontSize: 18, color: Colors.grey),
                  ),
                ],
              ),
            )
          : ListView.builder(
              padding: const EdgeInsets.all(16),
              itemCount: trashNotes.length,
              itemBuilder: (context, index) {
                final note = trashNotes[index];
                return Card(
                  margin: const EdgeInsets.only(bottom: 12),
                  child: ListTile(
                    title: Text(
                      note.title.isEmpty ? 'بدون عنوان' : note.title,
                      textDirection: TextDirection.rtl,
                      style: GoogleFonts.cairo(fontWeight: FontWeight.bold),
                    ),
                    subtitle: Text(
                      'حُذفت مؤخراً',
                      textDirection: TextDirection.rtl,
                      style: GoogleFonts.cairo(fontSize: 12),
                    ),
                    trailing: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        IconButton(
                          icon: const Icon(LucideIcons.rotateCcw, color: Colors.green),
                          onPressed: () => ref.read(trashNotesProvider.notifier).restoreNote(note),
                        ),
                        IconButton(
                          icon: const Icon(LucideIcons.trash2, color: Colors.redAccent),
                          onPressed: () => ref.read(trashNotesProvider.notifier).permanentlyDeleteNote(note),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
    );
  }

  void _confirmEmptyTrash(BuildContext context, WidgetRef ref, AppLocalizations l10n) async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(l10n.emptyTrash, textDirection: TextDirection.rtl),
        content: Text(l10n.confirmEmptyTrash, textDirection: TextDirection.rtl),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: Text(l10n.cancel)),
          TextButton(
            onPressed: () => Navigator.pop(context, true),
            child: Text(l10n.emptyTrash, style: const TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );

    if (confirm == true) {
      await ref.read(trashNotesProvider.notifier).emptyTrash();
    }
  }
}

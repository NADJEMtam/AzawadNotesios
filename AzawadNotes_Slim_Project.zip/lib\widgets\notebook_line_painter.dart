import 'package:flutter/material.dart';

class NotebookLinePainter extends CustomPainter {
  final double lineHeight;
  final Color lineColor;
  final double horizontalPadding;

  NotebookLinePainter({
    required this.lineHeight,
    required this.lineColor,
    this.horizontalPadding = 20.0,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = lineColor
      ..strokeWidth = 0.5;

    double y = 0;
    while (y < size.height) {
      canvas.drawLine(
        Offset(horizontalPadding, y),
        Offset(size.width - horizontalPadding, y),
        paint,
      );
      y += lineHeight;
    }
  }

  @override
  bool shouldRepaint(covariant NotebookLinePainter oldDelegate) {
    return oldDelegate.lineHeight != lineHeight || oldDelegate.lineColor != lineColor;
  }
}

import 'package:flutter/material.dart';
import '../data/models/note_segment.dart';
import 'azawad_flag_span.dart';

class RichNoteView extends StatelessWidget {
  final List<NoteSegment> segments;
  final TextStyle? textStyle;
  final int? maxLines;

  const RichNoteView({
    super.key,
    required this.segments,
    this.textStyle,
    this.maxLines,
  });

  @override
  Widget build(BuildContext context) {
    final style = textStyle ??
        const TextStyle(
          fontFamily: 'Cairo',
          fontSize: 17,
          height: 1.8,
          color: Colors.black87,
        );

    final spans = <InlineSpan>[];

    for (final seg in segments) {
      if (seg.type == SegmentType.text) {
        // Split on newlines so line breaks are preserved
        final lines = (seg.text ?? '').split('\n');
        for (int i = 0; i < lines.length; i++) {
          if (lines[i].isNotEmpty) {
            spans.add(TextSpan(text: lines[i], style: style));
          }
          if (i < lines.length - 1) {
            spans.add(const TextSpan(text: '\n'));
          }
        }
      } else if (seg.type == SegmentType.azawadFlag) {
        spans.add(AzawadFlagSpan(fontSize: style.fontSize ?? 17));
      }
    }

    return RichText(
      textDirection: TextDirection.rtl,
      maxLines: maxLines,
      overflow: maxLines != null ? TextOverflow.ellipsis : TextOverflow.clip,
      text: TextSpan(children: spans),
    );
  }
}

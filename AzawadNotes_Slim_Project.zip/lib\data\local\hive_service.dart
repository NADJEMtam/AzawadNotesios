import 'package:flutter/foundation.dart';
import 'package:hive_flutter/hive_flutter.dart';
import '../models/note_model.dart';

class HiveService {
  static const String notesBoxName = 'notes_box';

  static Future<void> init() async {
    await Hive.initFlutter();
    
    if (!Hive.isAdapterRegistered(0)) {
      Hive.registerAdapter(NoteAdapter());
    }

    try {
      final box = await Hive.openBox<Note>(notesBoxName);
      // Ensure box integrity by attempting a read
      if (box.isNotEmpty) {
        box.getAt(0);
      }
    } catch (e) {
      debugPrint('Critical: Hive box corrupted, resetting database. $e');
      // Robust cleanup: Delete and recreate if ANY error occurs during open or read
      await Hive.deleteBoxFromDisk(notesBoxName);
      await Hive.openBox<Note>(notesBoxName);
    }
  }

  static Box<Note> get notesBox => Hive.box<Note>(notesBoxName);
}

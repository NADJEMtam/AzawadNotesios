import 'package:flutter/material.dart';
import '../../../core/theme/app_colors.dart';
import 'dart:ui';

class PremiumToolbar extends StatelessWidget {
  final VoidCallback onFlagInsert;

  const PremiumToolbar({
    super.key,
    required this.onFlagInsert,
  });

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    
    return ClipRRect(
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 12, sigmaY: 12),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
          decoration: BoxDecoration(
            color: isDark 
                ? AppColors.nearBlack.withValues(alpha: 0.85) 
                : Colors.white.withValues(alpha: 0.85),
            border: Border(
              top: BorderSide(
                color: isDark ? Colors.white10 : Colors.black12,
                width: 0.5,
              ),
            ),
          ),
          child: Row(
            children: [
              _FlagButton(onTap: onFlagInsert),
              const Spacer(),
              _DoneButton(onTap: () => FocusScope.of(context).unfocus()),
            ],
          ),
        ),
      ),
    );
  }
}

class _FlagButton extends StatelessWidget {
  final VoidCallback onTap;

  const _FlagButton({required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(2),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(6),
          border: Border.all(
            color: Theme.of(context).brightness == Brightness.dark 
                ? Colors.white24 
                : Colors.black12,
            width: 1,
          ),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withValues(alpha: 0.1),
              blurRadius: 4,
              offset: const Offset(0, 2),
            ),
          ],
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(4),
          child: Image.asset(
            'assets/flags/azawad_flag.png',
            width: 32,
            height: 22,
            fit: BoxFit.cover,
          ),
        ),
      ),
    );
  }
}

class _DoneButton extends StatelessWidget {
  final VoidCallback onTap;

  const _DoneButton({required this.onTap});

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return TextButton(
      onPressed: onTap,
      style: TextButton.styleFrom(
        foregroundColor: isDark ? AppColors.azawadYellow : AppColors.azawadBlue,
        padding: const EdgeInsets.symmetric(horizontal: 16),
      ),
      child: const Text(
        'تم',
        style: TextStyle(
          fontFamily: 'Cairo',
          fontWeight: FontWeight.w900,
          fontSize: 16,
        ),
      ),
    );
  }
}

import 'package:flutter/material.dart';

class AppColors {
  // Azawad Flag Palette
  static const Color azawadRed = Color(0xFFED1C24);
  static const Color azawadYellow = Color(0xFFFFE401);
  static const Color azawadBlue = Color(0xFF2E75C4);
  static const Color azawadWhite = Color(0xFFFFFFFF);

  // Dark Mode Variants
  static const Color azawadRedDark = Color(0xFFD64A45);
  static const Color azawadBlueDark = Color(0xFF5B9BD5);
  static const Color azawadYellowDark = Color(0xFFF2D94E);

  // Neutral Colors
  static const Color deepCharcoal = Color(0xFF1A1A1A);
  static const Color offWhite = Color(0xFFF7F6F2);
  static const Color surfaceWhite = Color(0xFFFFFFFF);
  static const Color nearBlack = Color(0xFF121212);
  static const Color surfaceCharcoal = Color(0xFF1E1E1E);
  static const Color noteGrey = Color(0xFF2C2C2C); // Professional grey for notes
}

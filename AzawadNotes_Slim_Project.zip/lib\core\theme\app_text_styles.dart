import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'app_colors.dart';

class AppTextStyles {
  static TextStyle getArabicStyle({
    double fontSize = 20, // Increased size
    FontWeight fontWeight = FontWeight.normal,
    Color? color,
  }) {
    return GoogleFonts.cairo(
      fontSize: fontSize,
      fontWeight: fontWeight,
      color: color,
    );
  }

  static TextStyle getLatinStyle({
    double fontSize = 18, // Increased size
    FontWeight fontWeight = FontWeight.normal,
    Color? color,
  }) {
    return GoogleFonts.inter(
      fontSize: fontSize,
      fontWeight: fontWeight,
      color: color,
    );
  }

  static TextTheme getTextTheme(BuildContext context, {bool isDark = false}) {
    final baseColor = isDark ? AppColors.azawadWhite : AppColors.deepCharcoal;
    
    return TextTheme(
      displayLarge: GoogleFonts.amiri(
        fontSize: 36, // Larger
        fontWeight: FontWeight.bold,
        color: baseColor,
      ),
      titleLarge: GoogleFonts.tajawal(
        fontSize: 24, // Larger
        fontWeight: FontWeight.bold,
        color: baseColor,
      ),
      titleMedium: GoogleFonts.cairo(
        fontSize: 20, // Larger
        fontWeight: FontWeight.bold,
        color: baseColor,
      ),
      bodyLarge: GoogleFonts.cairo(
        fontSize: 18, // Larger
        fontWeight: FontWeight.normal,
        color: baseColor,
      ),
      bodyMedium: GoogleFonts.cairo(
        fontSize: 16, // Larger
        fontWeight: FontWeight.normal,
        color: baseColor,
      ),
    );
  }
}

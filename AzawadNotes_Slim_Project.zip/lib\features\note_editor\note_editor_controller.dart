import 'package:flutter/material.dart';
import '../../data/models/note_segment.dart';

class NoteEditorController extends ChangeNotifier {
  List<NoteSegment> _segments;
  int _activeTextIndex = 0;
  late TextEditingController textController;

  NoteEditorController({List<NoteSegment>? initialSegments})
      : _segments = initialSegments != null && initialSegments.isNotEmpty
            ? List<NoteSegment>.from(initialSegments)
            : [const NoteSegment.text('')] {
    _activeTextIndex = _lastTextIndex();
    textController = TextEditingController(text: _activeText);
    textController.addListener(_syncActiveSegment);
  }

  List<NoteSegment> get segments => List.unmodifiable(_segments);

  String get _activeText {
    if (_activeTextIndex < _segments.length &&
        _segments[_activeTextIndex].type == SegmentType.text) {
      return _segments[_activeTextIndex].text ?? '';
    }
    return '';
  }

  int _lastTextIndex() {
    for (int i = _segments.length - 1; i >= 0; i--) {
      if (_segments[i].type == SegmentType.text) return i;
    }
    return 0;
  }

  void _syncActiveSegment() {
    if (_activeTextIndex < _segments.length &&
        _segments[_activeTextIndex].type == SegmentType.text) {
      _segments[_activeTextIndex] = NoteSegment.text(textController.text);
    }
  }

  /// Inserts the Azawad flag at the current cursor position in the active text segment.
  void insertAzawadFlag() {
    _syncActiveSegment();

    final cursorPos = textController.selection.isValid
        ? textController.selection.baseOffset
        : textController.text.length;

    final fullText = textController.text;
    final before = fullText.substring(0, cursorPos);
    final after = fullText.substring(cursorPos);

    // If there's text after the cursor, we need to split.
    // If we're at the very end, we just append flag and a new text segment.
    
    final newSegments = <NoteSegment>[
      ..._segments.sublist(0, _activeTextIndex),
      NoteSegment.text(before),
      const NoteSegment.flag(),
      NoteSegment.text(after),
      ..._segments.sublist(_activeTextIndex + 1),
    ];

    _segments = newSegments;
    _activeTextIndex = _activeTextIndex + 2;

    textController.removeListener(_syncActiveSegment);
    textController.dispose();
    textController = TextEditingController(text: after)
      ..selection = const TextSelection.collapsed(offset: 0);
    textController.addListener(_syncActiveSegment);

    notifyListeners();
  }

  List<NoteSegment> getSegments() {
    _syncActiveSegment();
    return List<NoteSegment>.from(_segments);
  }

  @override
  void dispose() {
    textController.removeListener(_syncActiveSegment);
    textController.dispose();
    super.dispose();
  }
}

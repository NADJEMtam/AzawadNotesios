import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:lucide_icons_flutter/lucide_icons.dart';

class PrivacyPolicyScreen extends StatelessWidget {
  const PrivacyPolicyScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'سياسة الخصوصية',
          style: GoogleFonts.cairo(fontWeight: FontWeight.bold),
        ),
        leading: IconButton(
          icon: const Icon(LucideIcons.chevronRight),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(24.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            _buildSectionTitle('1. مقدمة', isDark),
            _buildSectionBody(
              'نحن في "ملاحظات أزوادي" نولي أهمية قصوى لخصوصيتك. توضح هذه السياسة كيف نتعامل مع بياناتك عند استخدام التطبيق على أجهزة Android و iOS.',
              isDark,
            ),
            _buildSectionTitle('2. جمع البيانات', isDark),
            _buildSectionBody(
              '• البيانات المحلية: يتم تخزين ملاحظاتك محلياً على جهازك فقط باستخدام قاعدة بيانات مشفرة.\n'
              '• الإعلانات: نستخدم AdMob لتقديم الإعلانات، والتي قد تجمع معرفات إعلانية مجهولة لتحسين تجربة الإعلانات.\n'
              '• تحليلات Firebase: قد نجمع بيانات تقنية مجهولة (مثل نوع الجهاز وإصدار النظام) لتحسين أداء التطبيق.',
              isDark,
            ),
            _buildSectionTitle('3. الصلاحيات', isDark),
            _buildSectionBody(
              'يطلب التطبيق صلاحية الوصول إلى الإنترنت لعرض الإعلانات وتحديث الميزات، وصلاحية التخزين لحفظ الملاحظات بشكل آمن.',
              isDark,
            ),
            _buildSectionTitle('4. حماية البيانات', isDark),
            _buildSectionBody(
              'بما أن الملاحظات تُخزن محلياً، فأنت المسؤول الأول عن أمن جهازك. نحن لا نرفع محتوى ملاحظاتك إلى أي خوادم خارجية.',
              isDark,
            ),
            _buildSectionTitle('5. التحديثات', isDark),
            _buildSectionBody(
              'قد نقوم بتحديث سياسة الخصوصية هذه من وقت لآخر. سيتم إخطارك بأي تغييرات عبر تحديث التطبيق.',
              isDark,
            ),
            const SizedBox(height: 40),
            Center(
              child: Text(
                'آخر تحديث: يوليو 2026',
                style: GoogleFonts.cairo(
                  fontSize: 12,
                  color: isDark ? Colors.white38 : Colors.black38,
                ),
              ),
            ),
            const SizedBox(height: 20),
          ],
        ),
      ),
    );
  }

  Widget _buildSectionTitle(String title, bool isDark) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12, top: 20),
      child: Text(
        title,
        textDirection: TextDirection.rtl,
        style: GoogleFonts.cairo(
          fontSize: 18,
          fontWeight: FontWeight.bold,
          color: isDark ? Colors.white : Colors.black87,
        ),
      ),
    );
  }

  Widget _buildSectionBody(String body, bool isDark) {
    return Text(
      body,
      textDirection: TextDirection.rtl,
      style: GoogleFonts.tajawal(
        fontSize: 15,
        height: 1.6,
        color: isDark ? Colors.white70 : Colors.black54,
      ),
    );
  }
}

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../data/models/note_model.dart';
import '../../data/models/note_segment.dart';
import '../../providers/notes_provider.dart';
import 'flag_text_editing_controller.dart';
import 'package:uuid/uuid.dart';
import '../../l10n/generated/app_localizations.dart';
import '../../core/theme/app_colors.dart';
import '../../core/ads/ads_service.dart';

import 'package:flutter/services.dart';

import 'widgets/premium_toolbar.dart';
import 'package:lucide_icons_flutter/lucide_icons.dart';
import '../../widgets/app_logo.dart';
import 'package:intl/intl.dart' as intl;

class NoteEditorScreen extends ConsumerStatefulWidget {
  final Note? note;
  final List<NoteSegment>? initialSegments;
  final String? initialTitle;

  const NoteEditorScreen({
    super.key, 
    this.note,
    this.initialSegments,
    this.initialTitle,
  });

  @override
  ConsumerState<NoteEditorScreen> createState() => _NoteEditorScreenState();
}

class _NoteEditorScreenState extends ConsumerState<NoteEditorScreen> {
  late FlagTextEditingController _bodyCtrl;
  late TextEditingController _titleCtrl;
  final FocusNode _bodyFocus = FocusNode();

  @override
  void initState() {
    super.initState();
    
    String initialContent = '';
    if (widget.note != null) {
      final segments = NoteSegment.decodeList(widget.note!.contentJson);
      initialContent = NoteSegment.toTokenizedString(segments);
    } else if (widget.initialSegments != null) {
      initialContent = NoteSegment.toTokenizedString(widget.initialSegments!);
    }

    _bodyCtrl = FlagTextEditingController(text: initialContent);
    _titleCtrl = TextEditingController(text: widget.note?.title ?? widget.initialTitle ?? '');
  }

  @override
  void dispose() {
    _bodyCtrl.dispose();
    _titleCtrl.dispose();
    _bodyFocus.dispose();
    super.dispose();
  }

  void _save() {
    final segments = NoteSegment.fromTokenizedString(_bodyCtrl.text);
    final note = Note(
      id: widget.note?.id ?? const Uuid().v4(),
      title: _titleCtrl.text.trim(),
      contentJson: NoteSegment.encodeList(segments),
      createdAt: widget.note?.createdAt ?? DateTime.now(),
      updatedAt: DateTime.now(),
      isPinned: widget.note?.isPinned ?? false,
      colorTag: widget.note?.colorTag ?? 0,
      tags: widget.note?.tags ?? [],
    );
    ref.read(notesProvider.notifier).addOrUpdateNote(note);
    AdsService().showInterstitialAd(); // Logic is inside AdsService
    Navigator.pop(context);
  }

  void _copyToClipboard() {
    final segments = NoteSegment.fromTokenizedString(_bodyCtrl.text);
    final plainText = NoteSegment.plainText(segments);
    final fullText = '${_titleCtrl.text}\n\n$plainText';
    
    Clipboard.setData(ClipboardData(text: fullText)).then((_) {
      HapticFeedback.mediumImpact();
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            behavior: SnackBarBehavior.floating,
            backgroundColor: AppColors.azawadBlue,
            content: Row(
              children: [
                const Icon(LucideIcons.checkCircle, color: Colors.white, size: 20),
                const SizedBox(width: 12),
                Text(
                  'تم نسخ الملاحظة بنجاح',
                  style: GoogleFonts.cairo(fontWeight: FontWeight.bold),
                ),
              ],
            ),
          ),
        );
      }
    });
  }

  void _delete() async {
    if (widget.note != null) {
      final confirm = await showDialog<bool>(
        context: context,
        builder: (context) => AlertDialog(
          title: const Text('حذف الملاحظة', textDirection: TextDirection.rtl),
          content: const Text('هل أنت متأكد من حذف هذه الملاحظة؟', textDirection: TextDirection.rtl),
          actions: [
            TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('إلغاء')),
            TextButton(
              onPressed: () => Navigator.pop(context, true), 
              child: const Text('حذف', style: TextStyle(color: Colors.red)),
            ),
          ],
        ),
      );

      if (confirm == true) {
        await ref.read(notesProvider.notifier).deleteNote(widget.note!);
        AdsService().showInterstitialAd(force: true); // Force on delete as it's less frequent
        if (mounted) Navigator.pop(context);
      }
    } else {
      Navigator.pop(context);
    }
  }

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context);
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final dateStr = intl.DateFormat('d MMMM yyyy, hh:mm a', 'en_US').format(widget.note?.updatedAt ?? DateTime.now());

    return Scaffold(
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        foregroundColor: isDark ? Colors.white : Colors.black,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(LucideIcons.chevronLeft, size: 24),
          onPressed: () => Navigator.pop(context),
        ),
        title: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            const AppLogo(size: 28),
            const SizedBox(width: 10),
            Text(
              'ملاحظات أزوادي',
              style: GoogleFonts.cairo(
                fontSize: 16,
                fontWeight: FontWeight.bold,
                color: isDark ? Colors.white70 : Colors.black54,
              ),
            ),
          ],
        ),
        centerTitle: true,
        actions: [
          IconButton(
            icon: const Icon(LucideIcons.copy, size: 20),
            onPressed: _copyToClipboard,
            tooltip: 'نسخ',
          ),
          IconButton(
            icon: const Icon(LucideIcons.trash2, size: 20, color: Colors.redAccent),
            onPressed: _delete,
            tooltip: 'حذف',
          ),
          const SizedBox(width: 4),
        ],
      ),
      body: Hero(
        tag: widget.note != null ? 'note_${widget.note!.id}' : 'new_note',
        child: Material(
          color: Colors.transparent,
          child: Column(
            children: [
              Expanded(
                child: SingleChildScrollView(
                  padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 10),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      Text(
                        dateStr,
                        textAlign: TextAlign.center,
                        style: GoogleFonts.cairo(
                          fontSize: 12,
                          color: isDark ? Colors.white24 : Colors.black26,
                        ),
                      ),
                      const SizedBox(height: 24),
                      TextField(
                        controller: _titleCtrl,
                        textDirection: TextDirection.rtl,
                        style: GoogleFonts.amiri(
                          fontSize: 36,
                          fontWeight: FontWeight.bold,
                          color: isDark ? Colors.white : Colors.black87,
                          height: 1.1,
                        ),
                        decoration: InputDecoration(
                          hintText: l10n?.title ?? 'العنوان',
                          hintStyle: TextStyle(
                            color: isDark ? Colors.white12 : Colors.black12,
                            fontFamily: GoogleFonts.amiri().fontFamily,
                          ),
                          border: InputBorder.none,
                        ),
                      ),
                      const SizedBox(height: 8),
                      _buildBody(),
                    ],
                  ),
                ),
              ),
              // --- Premium Glassmorphism Toolbar ---
              PremiumToolbar(
                onFlagInsert: () {
                  HapticFeedback.lightImpact();
                  _bodyCtrl.insertFlag();
                  _bodyFocus.requestFocus();
                },
              ),
            ],
          ),
        ),
      ),
      floatingActionButton: Padding(
        padding: const EdgeInsets.only(bottom: 60),
        child: FloatingActionButton(
          mini: true,
          backgroundColor: AppColors.azawadRed,
          onPressed: _save,
          child: const Icon(LucideIcons.save, color: Colors.white, size: 20),
        ),
      ),
    );
  }

  Widget _buildBody() {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return TextField(
      controller: _bodyCtrl,
      focusNode: _bodyFocus,
      maxLines: null,
      textDirection: TextDirection.rtl,
      keyboardType: TextInputType.multiline,
      textInputAction: TextInputAction.newline,
      style: GoogleFonts.tajawal(
        fontSize: 20,
        height: 1.8,
        color: isDark ? Colors.white.withValues(alpha: 0.9) : Colors.black87,
      ),
      decoration: InputDecoration(
        border: InputBorder.none,
        hintText: 'ابدأ تدوين أفكارك هنا...',
        hintStyle: TextStyle(
          color: isDark ? Colors.white10 : Colors.black12,
          fontFamily: GoogleFonts.tajawal().fontFamily,
        ),
        contentPadding: EdgeInsets.zero,
        isDense: true,
      ),
    );
  }
}

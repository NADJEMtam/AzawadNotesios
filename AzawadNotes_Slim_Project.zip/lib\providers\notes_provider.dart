import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../data/models/note_model.dart';
import '../data/repositories/notes_repository.dart';

final notesProvider = StateNotifierProvider<NotesNotifier, List<Note>>((ref) {
  final repository = ref.watch(notesRepositoryProvider);
  return NotesNotifier(repository);
});

final trashNotesProvider = StateNotifierProvider<TrashNotifier, List<Note>>((ref) {
  final repository = ref.watch(notesRepositoryProvider);
  return TrashNotifier(repository, ref);
});

class NotesNotifier extends StateNotifier<List<Note>> {
  final NotesRepository _repository;

  NotesNotifier(this._repository) : super([]) {
    loadNotes();
  }

  void loadNotes() {
    state = _repository.getAllNotes();
  }

  void searchNotes(String query) {
    final allNotes = _repository.getAllNotes();
    if (query.isEmpty) {
      state = allNotes;
    } else {
      state = allNotes.where((note) {
        final title = note.title.toLowerCase();
        final content = note.contentJson.toLowerCase(); // Simple check for now
        return title.contains(query.toLowerCase()) || content.contains(query.toLowerCase());
      }).toList();
    }
  }

  Future<void> addOrUpdateNote(Note note) async {
    await _repository.saveNote(note);
    loadNotes();
  }

  Future<void> deleteNote(Note note) async {
    await _repository.deleteNote(note);
    loadNotes();
  }
}

class TrashNotifier extends StateNotifier<List<Note>> {
  final NotesRepository _repository;
  final Ref _ref;

  TrashNotifier(this._repository, this._ref) : super([]) {
    loadTrash();
  }

  void loadTrash() {
    state = _repository.getDeletedNotes();
  }

  Future<void> restoreNote(Note note) async {
    note.isDeleted = false;
    await _repository.saveNote(note);
    loadTrash();
    _ref.read(notesProvider.notifier).loadNotes();
  }

  Future<void> permanentlyDeleteNote(Note note) async {
    await _repository.hardDeleteNote(note);
    loadTrash();
  }

  Future<void> emptyTrash() async {
    final deleted = _repository.getDeletedNotes();
    for (final note in deleted) {
      await _repository.hardDeleteNote(note);
    }
    loadTrash();
  }
}

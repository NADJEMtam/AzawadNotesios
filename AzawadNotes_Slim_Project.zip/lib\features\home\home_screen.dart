import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:lucide_icons_flutter/lucide_icons.dart';
import '../../providers/notes_provider.dart';
import 'widgets/note_card.dart';
import '../../l10n/generated/app_localizations.dart';
import '../../widgets/app_logo.dart';
import '../../data/models/note_model.dart';
import '../../widgets/ads/banner_ad_widget.dart';
import 'package:google_fonts/google_fonts.dart';

class HomeScreen extends ConsumerStatefulWidget {
  const HomeScreen({super.key});

  @override
  ConsumerState<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends ConsumerState<HomeScreen> {
  final TextEditingController _searchCtrl = TextEditingController();
  bool _isSearching = false;

  @override
  void dispose() {
    _searchCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final notes = ref.watch(notesProvider);
    final l10n = AppLocalizations.of(context)!;

    return Scaffold(
      appBar: AppBar(
        leading: Builder(
          builder: (context) => IconButton(
            icon: const Icon(LucideIcons.menu),
            onPressed: () => Scaffold.of(context).openDrawer(),
          ),
        ),
        title: _isSearching
            ? TextField(
                controller: _searchCtrl,
                autofocus: true,
                decoration: InputDecoration(
                  hintText: l10n.searchNotes,
                  border: InputBorder.none,
                  hintStyle: const TextStyle(color: Colors.white54),
                ),
                style: GoogleFonts.cairo(color: Colors.white),
                onChanged: (val) => ref.read(notesProvider.notifier).searchNotes(val),
              )
            : Text(
                l10n.appTitle,
                style: GoogleFonts.cairo(fontWeight: FontWeight.bold, fontSize: 20),
              ),
        centerTitle: true,
        actions: [
          IconButton(
            icon: Icon(_isSearching ? LucideIcons.x : LucideIcons.search),
            onPressed: () {
              setState(() {
                if (_isSearching) {
                  _searchCtrl.clear();
                  ref.read(notesProvider.notifier).loadNotes();
                }
                _isSearching = !_isSearching;
              });
            },
          ),
        ],
      ),
      drawer: _buildDrawer(context, l10n),
      body: Column(
        children: [
          Expanded(
            child: notes.isEmpty
                ? Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(Icons.note_add_outlined, size: 80, color: Colors.grey.withValues(alpha: 0.5)),
                        const SizedBox(height: 16),
                        Text(
                          l10n.noNotes,
                          style: GoogleFonts.cairo(fontSize: 18, color: Colors.grey),
                        ),
                      ],
                    ),
                  )
                : GridView.builder(
                    padding: const EdgeInsets.all(16),
                    gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 2,
                      crossAxisSpacing: 16,
                      mainAxisSpacing: 16,
                      childAspectRatio: 0.8,
                    ),
                    itemCount: notes.length,
                    itemBuilder: (context, index) {
                      final note = notes[index];
                      return NoteCard(
                        note: note,
                        onTap: () => context.push('/editor', extra: note),
                        onDelete: () => _confirmDelete(context, ref, note, l10n),
                      );
                    },
                  ),
          ),
          const BannerAdWidget(),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        backgroundColor: const Color(0xFFED1C24),
        onPressed: () => context.push('/editor'),
        label: Text(l10n.addNote, style: GoogleFonts.cairo(fontWeight: FontWeight.bold, color: Colors.white)),
        icon: const Icon(LucideIcons.plus, color: Colors.white),
      ),
    );
  }

  Widget _buildDrawer(BuildContext context, AppLocalizations l10n) {
    return Drawer(
      child: ListView(
        padding: EdgeInsets.zero,
        children: [
          DrawerHeader(
            decoration: const BoxDecoration(color: Color(0xFFED1C24)),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const AppLogo(size: 60),
                const SizedBox(height: 12),
                Text(
                  l10n.appTitle,
                  style: GoogleFonts.cairo(color: Colors.white, fontSize: 22, fontWeight: FontWeight.bold),
                ),
              ],
            ),
          ),
          ListTile(
            leading: const Icon(LucideIcons.stickyNote),
            title: Text(l10n.appTitle, style: GoogleFonts.cairo()),
            onTap: () => Navigator.pop(context),
          ),
          ListTile(
            leading: const Icon(LucideIcons.trash2),
            title: Text(l10n.trash, style: GoogleFonts.cairo()),
            onTap: () {
              Navigator.pop(context);
              context.push('/trash');
            },
          ),
          ListTile(
            leading: const Icon(LucideIcons.settings),
            title: Text(l10n.settings, style: GoogleFonts.cairo()),
            onTap: () {
              Navigator.pop(context);
              context.push('/settings');
            },
          ),
          ListTile(
            leading: const Icon(LucideIcons.shieldCheck),
            title: Text(l10n.privacyPolicy, style: GoogleFonts.cairo()),
            onTap: () {
              Navigator.pop(context);
              context.push('/privacy');
            },
          ),
        ],
      ),
    );
  }

  void _confirmDelete(BuildContext context, WidgetRef ref, Note note, AppLocalizations l10n) async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(l10n.delete, textDirection: TextDirection.rtl),
        content: const Text('هل تريد نقل هذه الملاحظة إلى سلة المهملات؟', textDirection: TextDirection.rtl),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: Text(l10n.cancel)),
          TextButton(
            onPressed: () => Navigator.pop(context, true), 
            child: Text(l10n.delete, style: const TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );

    if (confirm == true) {
      await ref.read(notesProvider.notifier).deleteNote(note);
      ref.read(trashNotesProvider.notifier).loadTrash();
    }
  }
}

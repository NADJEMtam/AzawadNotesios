import 'package:flutter/foundation.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';

class AdsService {
  static final AdsService _instance = AdsService._internal();
  factory AdsService() => _instance;
  AdsService._internal();

  // Test Ad Unit IDs (Google Official)
  static const String testAppOpenId = 'ca-app-pub-3940256099942544/9257395921';
  static const String testBannerId = 'ca-app-pub-3940256099942544/6300978111';
  static const String testInterstitialId = 'ca-app-pub-3940256099942544/1033173712';

  // Production Ad Unit IDs (For reference)
  // App Open: ca-app-pub-8785637407453940/1761927351
  // Banner: ca-app-pub-8785637407453940/7558993607
  // Interstitial: ca-app-pub-8785637407453940/4932830264

  AppOpenAd? _appOpenAd;
  bool _isShowingAppOpenAd = false;
  DateTime? _lastAppOpenShowTime;

  InterstitialAd? _interstitialAd;
  int _interstitialCounter = 0;
  DateTime? _lastInterstitialShowTime;

  bool _isInitialized = false;

  Future<void> initialize() async {
    if (_isInitialized) return;
    await MobileAds.instance.initialize();
    _isInitialized = true;
    loadAppOpenAd();
    loadInterstitialAd();
  }

  // --- App Open Ad ---
  void loadAppOpenAd() {
    AppOpenAd.load(
      adUnitId: kDebugMode ? testAppOpenId : 'ca-app-pub-8785637407453940/1761927351',
      request: const AdRequest(),
      adLoadCallback: AppOpenAdLoadCallback(
        onAdLoaded: (ad) {
          _appOpenAd = ad;
        },
        onAdFailedToLoad: (error) {
          debugPrint('AppOpenAd failed to load: $error');
        },
      ),
    );
  }

  void showAppOpenAdIfAvailable() {
    if (_appOpenAd == null || _isShowingAppOpenAd) {
      loadAppOpenAd();
      return;
    }

    // Frequency capping: 4 hours
    if (_lastAppOpenShowTime != null &&
        DateTime.now().difference(_lastAppOpenShowTime!).inHours < 4) {
      return;
    }

    _appOpenAd!.fullScreenContentCallback = FullScreenContentCallback(
      onAdShowedFullScreenContent: (ad) {
        _isShowingAppOpenAd = true;
      },
      onAdDismissedFullScreenContent: (ad) {
        _isShowingAppOpenAd = false;
        ad.dispose();
        _appOpenAd = null;
        _lastAppOpenShowTime = DateTime.now();
        loadAppOpenAd();
      },
      onAdFailedToShowFullScreenContent: (ad, error) {
        _isShowingAppOpenAd = false;
        ad.dispose();
        _appOpenAd = null;
        loadAppOpenAd();
      },
    );
    _appOpenAd!.show();
  }

  // --- Interstitial Ad ---
  void loadInterstitialAd() {
    InterstitialAd.load(
      adUnitId: kDebugMode ? testInterstitialId : 'ca-app-pub-8785637407453940/4932830264',
      request: const AdRequest(),
      adLoadCallback: InterstitialAdLoadCallback(
        onAdLoaded: (ad) {
          _interstitialAd = ad;
        },
        onAdFailedToLoad: (error) {
          debugPrint('InterstitialAd failed to load: $error');
        },
      ),
    );
  }

  void showInterstitialAd({bool force = false}) {
    _interstitialCounter++;

    if (!force) {
      // Logic: Every 5 actions AND at least 5 minutes since last show
      if (_interstitialCounter % 5 != 0) return;
      if (_lastInterstitialShowTime != null &&
          DateTime.now().difference(_lastInterstitialShowTime!).inMinutes < 5) {
        return;
      }
    }

    if (_interstitialAd == null) {
      loadInterstitialAd();
      return;
    }

    _interstitialAd!.fullScreenContentCallback = FullScreenContentCallback(
      onAdDismissedFullScreenContent: (ad) {
        ad.dispose();
        _interstitialAd = null;
        _lastInterstitialShowTime = DateTime.now();
        loadInterstitialAd();
      },
      onAdFailedToShowFullScreenContent: (ad, error) {
        ad.dispose();
        _interstitialAd = null;
        loadInterstitialAd();
      },
    );
    _interstitialAd!.show();
  }

  // --- Banner Ad Helper ---
  BannerAd createBannerAd(Function(Ad) onAdLoaded) {
    return BannerAd(
      adUnitId: kDebugMode ? testBannerId : 'ca-app-pub-8785637407453940/7558993607',
      size: AdSize.banner,
      request: const AdRequest(),
      listener: BannerAdListener(
        onAdLoaded: onAdLoaded,
        onAdFailedToLoad: (ad, error) {
          ad.dispose();
          debugPrint('BannerAd failed to load: $error');
        },
      ),
    );
  }
}

import 'dart:convert';

enum SegmentType { text, azawadFlag }

class NoteSegment {
  final SegmentType type;
  final String? text;

  const NoteSegment.text(String t)
      : type = SegmentType.text,
        text = t;

  const NoteSegment.flag()
      : type = SegmentType.azawadFlag,
        text = null;

  Map<String, dynamic> toJson() => {
        'type': type.name,
        if (text != null) 'text': text,
      };

  factory NoteSegment.fromJson(Map<String, dynamic> json) {
    if (json['type'] == 'azawadFlag' || json['type'] == 'image') return const NoteSegment.flag();
    return NoteSegment.text((json['text'] as String?) ?? (json['content'] as String?) ?? '');
  }

  /// Serialize a list of segments to a JSON string for storage (Hive/SQLite)
  static String encodeList(List<NoteSegment> segments) =>
      jsonEncode(segments.map((s) => s.toJson()).toList());

  /// Deserialize a list of segments from a stored JSON string
  static List<NoteSegment> decodeList(String jsonStr) {
    if (jsonStr.isEmpty) return [const NoteSegment.text('')];
    try {
      final list = jsonDecode(jsonStr) as List;
      return list
          .map((e) => NoteSegment.fromJson(e as Map<String, dynamic>))
          .toList();
    } catch (e) {
      return [NoteSegment.text(jsonStr)];
    }
  }

  /// Plain text preview — flag shown as 🚩 for search/snippet use
  static String plainText(List<NoteSegment> segments) =>
      segments.map((s) => s.type == SegmentType.azawadFlag ? '🚩' : s.text ?? '').join();

  /// Converts a tokenized string (with \uE000) back to segments for storage
  static List<NoteSegment> fromTokenizedString(String text) {
    const token = '\uE000';
    final segments = <NoteSegment>[];
    
    int lastEnd = 0;
    for (int i = 0; i < text.length; i++) {
      if (text[i] == token) {
        if (i > lastEnd) {
          segments.add(NoteSegment.text(text.substring(lastEnd, i)));
        }
        segments.add(const NoteSegment.flag());
        lastEnd = i + 1;
      }
    }
    
    if (lastEnd < text.length) {
      segments.add(NoteSegment.text(text.substring(lastEnd)));
    }
    
    return segments.isEmpty ? [const NoteSegment.text('')] : segments;
  }

  static String toTokenizedString(List<NoteSegment> segments) {
    return segments.map((s) => s.type == SegmentType.azawadFlag ? '\uE000' : s.text ?? '').join();
  }
}

// ignore: unused_import
import 'package:intl/intl.dart' as intl;
import 'app_localizations.dart';

// ignore_for_file: type=lint

/// The translations for Arabic (`ar`).
class AppLocalizationsAr extends AppLocalizations {
  AppLocalizationsAr([String locale = 'ar']) : super(locale);

  @override
  String get appTitle => 'ملاحظات أزوادي';

  @override
  String get searchNotes => 'ابحث عن ملاحظات...';

  @override
  String get noNotes => 'لا توجد ملاحظات';

  @override
  String get addNote => 'إضافة ملاحظة';

  @override
  String get settings => 'الإعدادات';

  @override
  String get darkMode => 'الوضع الداكن';

  @override
  String get language => 'اللغة';

  @override
  String get pinned => 'مثبت';

  @override
  String get delete => 'حذف';

  @override
  String get archive => 'أرشيف';

  @override
  String get title => 'العنوان';

  @override
  String get noteContent => 'اكتب ملاحظتك هنا...';

  @override
  String get save => 'حفظ';

  @override
  String get trash => 'سلة المهملات';

  @override
  String get restore => 'استعادة';

  @override
  String get emptyTrash => 'إفراغ السلة';

  @override
  String get permanentlyDelete => 'حذف نهائي';

  @override
  String get confirmEmptyTrash => 'هل أنت متأكد من إفراغ سلة المهملات؟';

  @override
  String get noTrash => 'السلة فارغة';

  @override
  String get cancel => 'إلغاء';

  @override
  String get about => 'حول التطبيق';

  @override
  String get version => 'الإصدار';

  @override
  String get injectDemoData => 'إضافة بيانات تجريبية';

  @override
  String get demoDataInjected => 'تمت إضافة البيانات التجريبية بنجاح';

  @override
  String get theme => 'المظهر';

  @override
  String get light => 'فاتح';

  @override
  String get dark => 'داكن';

  @override
  String get privacyPolicy => 'سياسة الخصوصية';
}

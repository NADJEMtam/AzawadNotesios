import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:lucide_icons_flutter/lucide_icons.dart';
import '../../providers/theme_provider.dart';
import '../../providers/notes_provider.dart';
import '../../core/utils/demo_service.dart';
import '../../data/repositories/notes_repository.dart';
import '../../l10n/generated/app_localizations.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../core/theme/app_colors.dart';

class SettingsScreen extends ConsumerWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final l10n = AppLocalizations.of(context)!;

    return Scaffold(
      appBar: AppBar(
        title: Text(
          l10n.settings,
          style: GoogleFonts.cairo(fontWeight: FontWeight.bold),
        ),
      ),
      body: ListView(
        children: [
          ListTile(
            leading: const Icon(LucideIcons.sunMoon),
            title: Text(l10n.theme, style: GoogleFonts.cairo()),
            trailing: Switch(
              value: Theme.of(context).brightness == Brightness.dark,
              onChanged: (_) => ref.read(themeProvider.notifier).toggleTheme(),
            ),
          ),
          const Divider(),
          ListTile(
            leading: const Icon(LucideIcons.database),
            title: Text(l10n.injectDemoData, style: GoogleFonts.cairo()),
            subtitle: Text('لأخذ لقطات شاشة بجودة عالية', style: GoogleFonts.cairo(fontSize: 12)),
            onTap: () async {
              final repo = ref.read(notesRepositoryProvider);
              await DemoService.injectDemoData(repo);
              ref.read(notesProvider.notifier).loadNotes();
              if (context.mounted) {
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    behavior: SnackBarBehavior.floating,
                    backgroundColor: AppColors.azawadBlue,
                    content: Row(
                      children: [
                        const Icon(LucideIcons.checkCircle, color: Colors.white, size: 20),
                        const SizedBox(width: 12),
                        Text(l10n.demoDataInjected, style: GoogleFonts.cairo(fontWeight: FontWeight.bold)),
                      ],
                    ),
                  ),
                );
              }
            },
          ),
          const Divider(),
          ListTile(
            leading: const Icon(LucideIcons.info),
            title: Text(l10n.about, style: GoogleFonts.cairo()),
            subtitle: Text('${l10n.version} 1.0.0', style: GoogleFonts.cairo(fontSize: 12)),
          ),
        ],
      ),
    );
  }
}

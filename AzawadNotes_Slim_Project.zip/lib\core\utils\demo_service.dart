import 'package:uuid/uuid.dart';
import '../../data/models/note_model.dart';
import '../../data/models/note_segment.dart';
import '../../data/repositories/notes_repository.dart';

class DemoService {
  static Future<void> injectDemoData(NotesRepository repository) async {
    final demoNotes = [
      Note(
        id: const Uuid().v4(),
        title: 'عن أزواد',
        contentJson: NoteSegment.encodeList([
          const NoteSegment.text('أزواد هي أرض الأحرار، موطن الطوارق والعرب والسونغاي. تمتاز بجمال صحرائها الشاسعة وقيمها العريقة. '),
          const NoteSegment.flag(),
          const NoteSegment.text('\n\nالعلم يمثل:\nالأحمر: دماء الشهداء\nالأصفر: رمال الصحراء\nالأزرق: السماء الصافية'),
        ]),
        createdAt: DateTime.now().subtract(const Duration(days: 2)),
        updatedAt: DateTime.now().subtract(const Duration(days: 2)),
      ),
      Note(
        id: const Uuid().v4(),
        title: 'قصيدة في حب الوطن',
        contentJson: NoteSegment.encodeList([
          const NoteSegment.text('يا أزواد يا فخر الزمان\nيا واحة في قلب الصحراء\nدمتِ حرة أبية '),
          const NoteSegment.flag(),
        ]),
        createdAt: DateTime.now().subtract(const Duration(days: 1)),
        updatedAt: DateTime.now().subtract(const Duration(days: 1)),
      ),
      Note(
        id: const Uuid().v4(),
        title: 'ملاحظة يومية',
        contentJson: NoteSegment.encodeList([
          const NoteSegment.text('تجهيز لقطات شاشة عالية الدقة للتطبيق الجديد. '),
          const NoteSegment.flag(),
          const NoteSegment.text(' يجب التأكد من تناسق الألوان والخطوط.'),
        ]),
        createdAt: DateTime.now(),
        updatedAt: DateTime.now(),
      ),
    ];

    for (final note in demoNotes) {
      await repository.saveNote(note);
    }
  }
}

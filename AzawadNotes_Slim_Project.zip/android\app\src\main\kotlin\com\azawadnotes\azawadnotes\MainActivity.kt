package com.azawadnotes.azawadnotes

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()

import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../models/note_model.dart';
import '../local/hive_service.dart';

final notesRepositoryProvider = Provider((ref) => NotesRepository());

class NotesRepository {
  List<Note> getAllNotes() {
    try {
      return HiveService.notesBox.values.where((note) => !note.isDeleted).toList()
        ..sort((a, b) => b.updatedAt.compareTo(a.updatedAt));
    } catch (e) {
      return [];
    }
  }

  List<Note> getDeletedNotes() {
    try {
      return HiveService.notesBox.values.where((note) => note.isDeleted).toList()
        ..sort((a, b) => b.updatedAt.compareTo(a.updatedAt));
    } catch (e) {
      return [];
    }
  }

  Future<void> saveNote(Note note) async {
    try {
      if (note.isInBox) {
        await note.save();
      } else {
        await HiveService.notesBox.put(note.id, note);
      }
    } catch (_) {}
  }

  Future<void> deleteNote(Note note) async {
    try {
      note.isDeleted = true;
      await note.save();
    } catch (_) {}
  }

  Future<void> hardDeleteNote(Note note) async {
    try {
      await note.delete();
    } catch (_) {}
  }
}

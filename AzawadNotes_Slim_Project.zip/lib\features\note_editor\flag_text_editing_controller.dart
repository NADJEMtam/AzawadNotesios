import 'package:flutter/material.dart';
import '../../widgets/azawad_flag_span.dart';

class FlagTextEditingController extends TextEditingController {
  // Use a single Unicode character from the Private Use Area to ensure atomic deletion
  static const String flagToken = '\uE000';

  FlagTextEditingController({super.text});

  @override
  TextSpan buildTextSpan({
    required BuildContext context,
    TextStyle? style,
    required bool withComposing,
  }) {
    final List<InlineSpan> children = [];
    
    // Iterate through text and find the token
    int lastEnd = 0;
    for (int i = 0; i < text.length; i++) {
      if (text[i] == flagToken) {
        // Add text before the flag
        if (i > lastEnd) {
          children.add(TextSpan(
            text: text.substring(lastEnd, i),
            style: style,
          ));
        }
        
        // Add the flag widget span - size matches font size
        children.add(AzawadFlagSpan(fontSize: style?.fontSize ?? 22));
        
        lastEnd = i + 1;
      }
    }

    // Add remaining text
    if (lastEnd < text.length) {
      children.add(TextSpan(
        text: text.substring(lastEnd),
        style: style,
      ));
    }

    return TextSpan(children: children, style: style);
  }

  void insertFlag() {
    final text = this.text;
    final selection = this.selection;
    
    if (!selection.isValid) {
      final newText = text + flagToken;
      value = TextEditingValue(
        text: newText,
        selection: TextSelection.collapsed(offset: newText.length),
      );
      return;
    }

    final newText = text.replaceRange(
      selection.start,
      selection.end,
      flagToken,
    );
    
    value = TextEditingValue(
      text: newText,
      selection: TextSelection.collapsed(
        offset: selection.start + flagToken.length,
      ),
    );
  }
}

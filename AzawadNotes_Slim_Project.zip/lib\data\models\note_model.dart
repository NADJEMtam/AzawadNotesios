import 'package:hive/hive.dart';

part 'note_model.g.dart';

@HiveType(typeId: 0)
class Note extends HiveObject {
  @HiveField(0)
  late String id;

  @HiveField(1)
  late String title;

  @HiveField(2)
  late String contentJson; // Stores JSON encoded List<NoteSegment>

  @HiveField(3)
  late DateTime createdAt;

  @HiveField(4)
  late DateTime updatedAt;

  @HiveField(5)
  late bool isPinned;

  @HiveField(6)
  late int colorTag;

  @HiveField(7)
  late List<String> tags;

  @HiveField(8)
  late bool isDeleted;

  Note({
    required this.id,
    required this.title,
    required this.contentJson,
    required this.createdAt,
    required this.updatedAt,
    this.isPinned = false,
    this.colorTag = 0,
    this.tags = const [],
    this.isDeleted = false,
  });
}

import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'features/home/home_screen.dart';
import 'features/splash/splash_screen.dart';
import 'features/note_editor/note_editor_screen.dart';
import 'features/trash/trash_screen.dart';
import 'features/settings/settings_screen.dart';
import 'features/settings/privacy_policy_screen.dart';
import 'data/models/note_model.dart';

import 'package:flutter_localizations/flutter_localizations.dart';
import 'l10n/generated/app_localizations.dart';
import 'core/theme/app_theme.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'core/ads/app_open_observer.dart';
import 'providers/theme_provider.dart';

class AzawadNotesApp extends ConsumerStatefulWidget {
  const AzawadNotesApp({super.key});

  @override
  ConsumerState<AzawadNotesApp> createState() => _AzawadNotesAppState();
}

class _AzawadNotesAppState extends ConsumerState<AzawadNotesApp> {
  final AppOpenObserver _appOpenObserver = AppOpenObserver();

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(_appOpenObserver);
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(_appOpenObserver);
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final themeMode = ref.watch(themeProvider);

    return MaterialApp.router(
      onGenerateTitle: (context) {
        try {
          return AppLocalizations.of(context)?.appTitle ?? 'Azawad Notes';
        } catch (_) {
          return 'Azawad Notes';
        }
      },
      routerConfig: router,
      debugShowCheckedModeBanner: false,
      theme: AppTheme.lightTheme,
      darkTheme: AppTheme.darkTheme,
      themeMode: themeMode,
      localizationsDelegates: const [
        AppLocalizations.delegate,
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      supportedLocales: const [
        Locale('en'),
        Locale('ar'),
      ],
    );
  }
}

final GoRouter router = GoRouter(
  navigatorKey: rootNavigatorKey,
  initialLocation: '/',
  routes: [
    GoRoute(
      path: '/',
      builder: (context, state) => const SplashScreen(),
    ),
    GoRoute(
      path: '/home',
      builder: (context, state) => const HomeScreen(),
    ),
    GoRoute(
      path: '/editor',
      builder: (context, state) {
        final note = state.extra as Note?;
        return NoteEditorScreen(note: note);
      },
    ),
    GoRoute(
      path: '/trash',
      builder: (context, state) => const TrashScreen(),
    ),
    GoRoute(
      path: '/settings',
      builder: (context, state) => const SettingsScreen(),
    ),
    GoRoute(
      path: '/privacy',
      builder: (context, state) => const PrivacyPolicyScreen(),
    ),
  ],
);

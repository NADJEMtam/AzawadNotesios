import 'package:flutter/material.dart';
import 'ads_service.dart';
import 'package:go_router/go_router.dart';

class AppOpenObserver extends WidgetsBindingObserver {
  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      // Check if we are NOT in the editor
      final context = rootNavigatorKey.currentContext;
      if (context != null) {
        final location = GoRouterState.of(context).matchedLocation;
        if (location != '/editor') {
          AdsService().showAppOpenAdIfAvailable();
        }
      }
    }
  }
}

// We need the navigator key to check current route
final GlobalKey<NavigatorState> rootNavigatorKey = GlobalKey<NavigatorState>();

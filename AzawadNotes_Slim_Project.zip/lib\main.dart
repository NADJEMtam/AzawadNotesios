import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'data/local/hive_service.dart';
import 'app.dart';
import 'core/ads/ads_service.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  
  await AdsService().initialize();
  // Set up global error handling
  FlutterError.onError = (details) {
    FlutterError.presentError(details);
    debugPrint('Flutter Error: ${details.exception}');
  };

  try {
    await HiveService.init();
  } catch (e) {
    debugPrint('Hive Init Error: $e');
  }
  
  runApp(const ProviderScope(child: AzawadNotesApp()));
}
